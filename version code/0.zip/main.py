import sys
import time

import pygame

from colors import Colors
from menu_state import MenuState
from sound_manager import SoundManager
from start_state import StartState


class Game:
    def __init__(self):
        self.enter_pressed = False
        self.state = MenuState()
        pygame.init()
        SoundManager.play_menu_sound()
        self.screen_width = 800
        self.screen_height = 600
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
        pygame.display.set_caption("Dragon Ball Z : I Leggendari Super Guerrieri")

        # Caricamento e ridimensionamento dell'immagine di sfondo
        self.background = pygame.image.load("resources/images/Icons/menu.png")
        self.background = pygame.transform.scale(self.background, (self.screen_width, self.screen_height))

        # Caricamento del font personalizzato
        font_path = "resources/Fonts/pkmn rbygsc.ttf"  # Sostituisci con il percorso del tuo file di font
        self.custom_font = pygame.font.Font(font_path, 36)
        self.start_state = StartState()  # Nuovo stato di avvio
        self.enter_pressed = False

    def run(self):
        running = True
        start_text_rect = ""
        self.screen.blit(self.background, (0, 0))
        pygame.display.flip()
        while running:
            dt = pygame.time.Clock().tick(60) / 1000  # Calcola il tempo trascorso

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif self.enter_pressed is False:
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_RETURN:
                            self.enter_pressed = True
                            SoundManager.play_click_sound()  # Suono di click
                            # Pulizia dello schermo
                            self.screen.blit(self.background, (0, 0))
                            self.state = MenuState()
                else:
                    self.state.handle_input(event)  # Gestisci l'input

            self.start_state.update(dt)  # Aggiorna lo stato di avvio

            # Mostra il messaggio di start solo se "ENTER" non è stato premuto
            if not self.enter_pressed:
                # Pulizia dello schermo
                self.screen.blit(self.background, (0, 0))
                pygame.display.flip()
                # disegno dello schermo START
                time.sleep(0.5)
                start_text = self.custom_font.render(self.start_state.message, True, Colors.GRAY)
                start_text_rect = start_text.get_rect(center=(self.screen_width // 2, self.screen_height // 2))
                self.screen.blit(start_text, start_text_rect)
                pygame.display.flip()  # Aggiornamento dello schermo
                time.sleep(0.5)

            # Mostra le opzioni del menu solo se "ENTER" è stato premuto
            if self.enter_pressed:
                for i, option in enumerate(self.state.options):
                    text = self.custom_font.render(option, True,
                                                   (Colors.WHITE if i == self.state.selected_option else Colors.GRAY))
                    text_rect = text.get_rect(center=(self.screen_width // 2, self.screen_height // 2 + i * 50))
                    self.screen.blit(text, text_rect)
                pygame.display.flip()
            pygame.display.flip()

        pygame.quit()
        sys.exit()


if __name__ == "__main__":
    game = Game()
    game.run()
