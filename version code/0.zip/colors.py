class Colors:
    WHITE = (255, 255, 255)
    GRAY = (150, 150, 150)
    BLACK = (0, 0, 0)
    GRAY_MEDIUM = (128, 128, 128)
