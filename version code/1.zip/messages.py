class Messages:
    INIT_MENU_OPTION = ["Nuova Partita", "Carica Partita", "Opzioni", "Esci"]
    SAVE_SLOTS = ['Slot 1', 'Slot 2', 'Slot 3', 'Esci']
    MAP_MENU_OPTION = ['Pers.', 'Piano', 'Lista', 'Salva', 'Chiudi']


